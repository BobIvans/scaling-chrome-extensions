const emoji = "🧪";
// import run from "./util.js";
export function caller() { return 1; }
