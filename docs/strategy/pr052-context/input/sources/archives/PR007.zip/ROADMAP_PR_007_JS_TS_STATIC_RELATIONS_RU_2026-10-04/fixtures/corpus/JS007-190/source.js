// tail variant
const note = "export { run } from './util.js'";
export function caller() { return 1; }
