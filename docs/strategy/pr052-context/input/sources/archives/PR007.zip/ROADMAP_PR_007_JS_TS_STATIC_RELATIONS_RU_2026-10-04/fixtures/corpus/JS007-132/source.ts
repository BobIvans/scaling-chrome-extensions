// RU: Я и связь
import { run } from "./util";
export function caller() { return 1; }
