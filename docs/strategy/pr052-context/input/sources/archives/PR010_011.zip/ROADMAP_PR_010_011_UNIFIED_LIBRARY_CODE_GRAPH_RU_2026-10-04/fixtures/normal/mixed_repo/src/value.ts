export const value = "value";
