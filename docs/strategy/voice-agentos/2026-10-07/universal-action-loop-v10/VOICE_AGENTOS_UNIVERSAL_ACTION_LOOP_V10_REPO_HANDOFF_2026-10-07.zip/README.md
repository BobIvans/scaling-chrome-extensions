# Universal Action Loop V10

Implementation addendum for the existing Voice AgentOS roadmap.

Target runtime:
`Goal → Observe → Discover capability → Choose route → Execute → Reobserve → Verify → Recover → Learn`

Fallback order:
`registered capability/API/WebMCP → CDP/DOM/AX → qualified site adapter → Windows UIA/native → screenshot/vision action proposal → human`

This does not claim universal automation is implemented today. It defines the missing fallback contract.
