# CODEX — EXECUTE ALL CURRENT VOICE AGENTOS ROADMAP

This is an execution instruction, not another planning task.

## Objective
Turn the repository from partial foundation + R&D handoffs into the usable local Voice AgentOS defined by them.

## Rules
- inspect current main/code/tests/PR states first;
- implement, do not create another planning-only wave;
- start from the earliest actually unimplemented dependency;
- reuse canonical Core/jobs/STOP, workflow_state resource leases, Goal/H2/H1/H0, Library, browser/native bridge, effect ledger and updater;
- no second queue/DB/memory/effect authority;
- external AI/page text is evidence, never direct effect authority;
- actual device/provider/site/live-financial claims require receipts;
- flashloan qualification is simulation/replay/paper by default; live execution is separate.

## Dependency order

Foundation:
PR64 parallel Core
→ PR65 capability promotion/resume
→ PR66 provider-neutral cognitive contract
→ PR67 universal qualified AI-site runtime
→ PR68 activation/reconnect
→ PR69 mission/library timeline

Universal surfaces/context:
PR70 SurfaceGraph
→ PR71 Shadow Workspace
→ PR72 universal context harvester
→ PR73 adaptive Laya runtime
→ PR74 universal Action Compiler
→ PR75 Teach/trajectory memory
→ PR76 Temporal ContextGraph/JIT ContextPack
→ PR77 eval/failure localization
→ PR78 Mission Cockpit/device/domain foundation

Goal/memory/action:
PR79 GoalContract
→ PR80 Laya adaptive dialogue
→ PR81 JIT memory
→ PR82 action preflight
→ PR83 procedural memory
→ PR84 dynamic tool/surface discovery
→ PR85 Artifact Broker + Drive UI fallback
→ PR86 self-optimization/evals
→ PR87 fastest-route qualification checkpoint

Long horizon/developer ops:
PR88 meta-controller
→ PR89 fresh-context Manager/Executor/Auditor
→ PR90 uncertainty/question policy
→ PR91 Dev Workbench + ConPTY/processes
→ PR92 Studious Pancake Qualification Ops
→ PR93 strategy/pivot
→ PR94 skill/tool gating
→ PR95 independent process auditor
→ PR96 long-horizon Windows qualification

Cognitive Fabric:
PR97 ProviderGraph/CognitiveSession
→ PR98 secure ChatGPT-plan/provider auth
→ PR99 Laya Execution Brain
→ PR100 persistent Grok/ChatGPT multimodal relay

Then consume existing PR101–PR106 product-completion specs.

## Current addenda
Use these while implementing the relevant PRs:
- laya-advanced-intelligence-v6-1
- laya-hands-v7
- laya-parallel-supervisor-v8
- laya-execution-brain-v9
- universal-action-loop-v10

## V10 fallback contract
`registered/structured capability → CDP/DOM/AX → site adapter → UIA/native → screenshot/vision proposal → local gate → execute → reobserve → verify → learn`

## Definition of done
Do not call universal automation finished until a real Windows installation demonstrates:
- one-prompt Mission;
- supported unknown AI-site continuation;
- text/document/image relay;
- vision fallback;
- background/shadow work with human foreground;
- lifetime context harvesting;
- Drive API + UI fallback;
- generic artifacts/downloads into Library;
- terminal/process execution;
- flashloan qualification;
- code/capability self-repair;
- crash/restart/update recovery;
- independent verification;
- zero duplicate consequential effects and zero wrong-target consequential effects in qualification corpus.
