# Screen-to-Action fallback

Build a VisionTaskPacket from:
- screenshot;
- exact screen/window/tab identity;
- geometry;
- optional DOM/AX/UIA candidates;
- optional numbered overlay;
- active goal gap;
- allowed action types;
- prohibited actions.

AI returns only a typed action proposal.

Local runtime:
1. check same world revision/window bounds;
2. prefer structured element if available;
3. allow coordinate fallback only when structured route is unavailable;
4. enforce effect/approval/human-lease rules;
5. execute;
6. recapture/reobserve;
7. verify expected state delta.

If expected delta did not occur, reobserve/recover; do not blindly click again.
