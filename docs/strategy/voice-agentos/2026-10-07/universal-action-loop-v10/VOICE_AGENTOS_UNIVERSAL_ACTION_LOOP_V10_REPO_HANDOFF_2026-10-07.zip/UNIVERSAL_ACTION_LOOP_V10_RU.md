# Universal Action Loop V10

For any supported site/app, AgentOS should try:

1. Registered capability / domain API
2. WebMCP / structured page tool
3. CDP / DOM / accessibility semantics
4. Qualified site adapter
5. Windows native/UIA
6. Vision grounding fallback
7. Human only if intent/authority/credential/target cannot be safely resolved

Vision is evidence, never authority.

The model returns a typed `VisionActionProposal`; local AgentOS validates world revision, target, effect scope, human lease, resource conflicts and approval requirements before execution.

After every action:
`execute → fresh observation → expected-vs-actual delta → ProgressDelta`

No blind retry after unknown effects.
