# Belief / Execution State

## Why

A long-horizon agent should distinguish:
- what is proven;
- what was merely observed;
- what a model believes;
- what is still unknown.

Otherwise incorrect earlier steps poison later reasoning.

## Active state tree

Each subgoal/action creates a branch.

Only an Auditor-accepted branch is allowed into the active root→current path.

Failed branches remain available as failure memory but are not included as current truth.

## Operations

- GROW: add new action/observation trace;
- VERIFY: accept/reject actual progress;
- COMPRESS: summarize a completed verified subgoal;
- REVISE: restore a verified boundary and create a new route;
- INVALIDATE: detach evidence that became stale.

## Belief fields

For critical unknowns track:
- hypothesis alternatives;
- evidence for/against;
- freshness;
- resolution action;
- consequence if wrong.

Laya's next action should often be the action that reduces the most consequential uncertainty, not the action that looks most “agentic”.
