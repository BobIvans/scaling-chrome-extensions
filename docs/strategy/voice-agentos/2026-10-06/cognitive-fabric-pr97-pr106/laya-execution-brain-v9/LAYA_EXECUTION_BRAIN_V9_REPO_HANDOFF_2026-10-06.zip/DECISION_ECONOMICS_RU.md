# Decision Economics / Value Router

## Principle

The smartest route is not necessarily the strongest model.

For every candidate resolver estimate:

`Expected Utility =
P(success) * ProgressValue
+ InformationGain
+ UnlockValue
- LatencyCost
- MoneyOrQuotaCost
- HumanAttentionCost
- RiskPenalty
- ResourcePressure`

For high-consequence effects increase the required success threshold instead of allowing cheap latency to compensate for poor quality.

## Context-aware router

Routing priors are indexed by:
- TaskClass;
- surface/app;
- provider/tool;
- modality;
- context size band;
- consequence level;
- recent drift/failure signature.

## Feedback

After local verification:
- success → update reliability;
- failure → attach failure class;
- expensive unnecessary escalation → regret event;
- faster equivalent route → positive comparative evidence.

## Research signal

CASTER reports large cost savings from context-aware model routing while matching strong-model success in its evaluated domains.
Agent-as-a-Router frames routing as Context→Action→Feedback→Context rather than one-off classification.

V9 follows the same principle but uses task-native local verification whenever available.
