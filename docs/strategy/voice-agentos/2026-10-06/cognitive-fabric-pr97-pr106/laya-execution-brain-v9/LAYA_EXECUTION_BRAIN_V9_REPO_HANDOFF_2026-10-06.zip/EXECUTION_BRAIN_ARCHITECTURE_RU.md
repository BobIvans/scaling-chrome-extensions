# Laya Execution Brain Architecture

## Brain does not equal LLM

The Brain is a local control system with small typed decisions.

A strong model is one possible cognitive resource.

## Seven internal controllers

### B1 — Verified State Controller
Maintains only independently verified current state.
Failed/unverified branches never contaminate the active state.

### B2 — Goal Frontier Controller
Reduces long goals into the smallest useful open acceptance/subgoal edge.
This keeps reasoning horizons short.

### B3 — Evidence / Memory Controller
Selects the smallest combination of:
- exact raw evidence;
- temporal/project graph;
- recent verified events;
- procedures;
- failure memory;
- live surface state;
- provider/session state.

### B4 — Value Router
For each possible resolver/tool/provider estimate:
- success probability;
- expected progress;
- information gain;
- latency;
- monetary/plan cost;
- human attention;
- risk;
- resource pressure.

Choose the cheapest route that clears the required success threshold.

### B5 — Parallel / Anytime Controller
Launch independent safe lanes.
Consume first useful evidence immediately.
Cancel or deprioritize work whose marginal value became low.

### B6 — Verifier Controller
Every consequential step has a specific process/outcome rubric.
A provider saying “done” has zero authority.

### B7 — Learning Controller
Update empirical route/tool/provider/procedure priors from verified outcomes.
If an expensive discovered path becomes stable, compile and promote a cheaper deterministic procedure.

## Grok in V9

Grok is a strategic lane:
- initial hard-goal review;
- novel semantic gap;
- repeated verified failure;
- strategy contradiction;
- code/capability design.

Grok is not called for routine progress confirmation.

Its result is bound to a `world_revision`.
If the local verified state changes enough, stale advice is discarded.
