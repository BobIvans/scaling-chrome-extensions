# Flashloan Execution Brain Example

Goal:
“Find the highest-value next qualification experiment and run it.”

## B1 Verified State

Load only:
- latest accepted campaign state;
- exact repo SHA;
- latest source-health receipts;
- prior simulation/paper results;
- open blockers.

## B2 Goal Frontier

Choose one open edge, e.g.:
“determine whether route family X fails because of stale quotes or execution constraints.”

## B3 Evidence Memory

Retrieve:
- matching prior failures;
- current route JSON;
- RPC state;
- aggregator quote history;
- relevant simulator logs;
- code symbols.

## B4 Value Router

Candidates:
A — deterministic log classifier
B — RPC refresh
C — DEX dashboard read
D — replay simulation
E — Grok diagnosis
F — Codex code analysis

Start cheaper/high-value reads first.

## B5 Parallel Anytime

Run A+B+C+D in parallel if resource-safe.
Grok E may start only if novelty/uncertainty threshold is met.
Stop redundant lanes when exact evidence resolves the failure.

## B6 Verify

Auditor checks:
- exact input version;
- RPC freshness;
- simulator process/log receipt;
- structured result;
- acceptance thresholds.

## B7 Learn

If the same failure signature is resolved repeatedly:
compile a deterministic diagnostic/recovery procedure.

The next campaign becomes faster and uses less Grok/API.
