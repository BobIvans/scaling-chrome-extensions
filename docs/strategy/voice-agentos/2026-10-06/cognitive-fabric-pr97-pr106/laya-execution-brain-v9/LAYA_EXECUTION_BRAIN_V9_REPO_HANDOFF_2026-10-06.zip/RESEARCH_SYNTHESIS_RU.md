# Research synthesis for Execution Brain V9

## Context-aware routing

CASTER proposes a lightweight context-aware strategy router rather than assigning strong models to every subtask; its reported experiments show large inference-cost reduction while matching strong-model performance in evaluated domains.

Agent-as-a-Router formalizes routing as Context → Action → Feedback → Context, explicitly learning from execution-grounded outcomes.

Implication:
our provider/tool router should be a feedback system, not a fixed rule table.

## Long-horizon state

MAGE treats memory as execution-state management using a hierarchical state tree so failed branches do not pollute the active state.

Agent-BRACE motivates maintaining explicit uncertainty/belief state in partially observed long tasks.

Implication:
Laya should act on verified state + explicit unknowns, not raw accumulated chat history.

## Memory selection

MESA argues that the optimal memory input is usually a query-specific combination of structures rather than one memory or the union of all memories.

ACON optimizes context compression and learns from cases where compressed context caused failures.

Implication:
V9 selects memory structures and learns compression/retrieval mistakes from verification.

## Horizon reduction

Recent horizon-length work finds that long action sequences themselves create severe exploration/credit-assignment difficulty, and reducing effective horizon improves stability.

Implication:
the Brain constantly reduces the mission to a short verifiable active edge.

## Verifiers

Microsoft's Universal Verifier work emphasizes specific non-overlapping rubrics and separating process from outcome/control failures.

Implication:
the verifier is part of the brain's reward signal.

## Tools

Chrome's WebMCP guidance warns that exposing too many tools increases context/token usage, latency and tool-selection confusion.

Implication:
the Brain dynamically selects the smallest relevant tool set.

## Repeatability

Stagehand combines AI for unfamiliar tasks with cached deterministic execution for known flows.

Implication:
expensive cognition should continuously turn into cheaper registered procedures.

## Grok

Grok Build supports parallel/background workflows and subagents.

Implication:
Grok can be one asynchronous strategic lane while Laya continues exact local work.
