# Verifier / Reward Loop

## Every important outcome needs a rubric

Rubric criteria must be:
- specific;
- non-overlapping;
- directly observable where possible;
- separated into process vs outcome.

## Example: “download all relevant Drive docs”

Process:
- exact authorized account/folder;
- pagination exhausted;
- every selected file produced download/export receipt;
- no blocked item hidden.

Outcome:
- artifact bytes exist;
- hashes recorded;
- Library records created;
- coverage report complete.

## Example: “simulation qualification passed”

Process:
- exact repo/version/config;
- exact route/input;
- simulator command/process receipt;
- no orphan/unknown process.

Outcome:
- structured simulation result;
- expected acceptance thresholds;
- log/artifact provenance.

## Reward signals

Update routing learning from:
- criterion closure;
- wrong-target rate;
- duplicate effect;
- latency;
- model/API spend;
- human interruption;
- recovery success;
- context bytes;
- procedure reuse.

## Research signal

Microsoft's Universal Verifier work reports that careful rubric design and separating process from outcome sharply reduces false-positive success judgments.
