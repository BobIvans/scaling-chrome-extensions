# Out-of-box skills — intended completed product

## 1. Ask / Do
Voice or text goal → GoalContract → mission.

## 2. Observe Current
Explain exact current tab/window/app/workspace without effects.

## 3. Harvest Context
Gather permitted:
- old AI chats;
- Google Drive;
- web pages;
- downloads;
- local files;
- repo/logs;
- authorized web3 dashboards.

Store/label/version/provenance automatically.

## 4. Find Everything
“Find everything we know about X.”
Adaptive memory selector builds an evidence pack.

## 5. Continue in AI
Build TaskPacket and continue exact Grok/ChatGPT session.
Capture answer and artifacts back into Library.

## 6. Parallel Research
Run independent tabs/data/repo/search lanes.
First useful evidence immediately replans the mission.

## 7. Web Navigation
Prefer WebMCP/API/CDP/DOM/AX, then UIA/vision fallback.
Known route executes without strong AI.

## 8. Teach / Learn
User demonstration or AI-discovered route → procedure → replay/canary → registered skill.

## 9. Develop
Run registered terminal/process/code/test/PR/CI workflows from Dev Workbench.

## 10. Self-Repair
Missing capability → code worker → tests → canary → register → resume original Goal.

## 11. Flashloan Qualification
Coordinate:
- repo;
- historical context;
- data sources;
- RPC;
- DEX/API;
- authorized web3 UI;
- simulation/replay;
- paper qualification;
- code repair;
- evidence report.

No live-trading authority by default.

## 12. Human Coexistence
Safe agent lanes continue in background while foreground mutable UI belongs to the user.
