# Current gaps relevant to Execution Brain V9

Authoring baseline: current repo has a strong observation/persistence foundation but most future implementation waves are still docs/R&D.

## Already in code

- canonical Library, versions/provenance, search, annotations;
- streamed browser chat archive;
- BrowserWatch;
- local folders, conversation exports and Drive API ingestion;
- tab list and tab-id browser calls;
- generic browser UI inventory and READ_NAV;
- Windows UIA fallback;
- human foreground lease;
- Laya client/supervisor;
- parallel Library/browser/Windows *prefetch*;
- utility scoring;
- durable Goal/H2/H1/H0 and restart resume;
- text AI-site send/reconcile primitive;
- Codex relay primitive;
- candidate patch/test/PR/CI foundations.

## Missing execution-brain functions

1. No durable `ExecutionStateTree` separating verified active state from failed branches.
2. No explicit belief/uncertainty state; current choices are mostly based on current candidates.
3. No adaptive memory-structure selector; retrieval is not yet task-adaptive across raw facts, graph, procedures, failures and live surface state.
4. No learned cost/quality/latency routing priors per task class/provider/tool.
5. No feedback loop where verified success/failure updates routing decisions.
6. No true resource-aware parallel lane execution.
7. No anytime controller that stops expensive lanes once enough evidence exists.
8. No process/outcome verifier rubric bound to every important acceptance criterion.
9. No horizon-reduction controller that aggressively converts long goals into short verified subgoals.
10. No predictive next-need/prefetch controller in runtime.
11. No route-regret / opportunity-cost tracking for “we called Grok but exact code would have worked.”
12. No automatic promotion of stable model-discovered routes toward deterministic procedures.
13. No runtime tool-set minimizer; too many available tools can create context/selection noise.
14. No robust stale-Grok-result rejection based on world-state revision.
15. No empirical “success probability” for a route beyond manually defined utility features.
16. No first-class Flashloan execution brain combining context/data/simulation/code lanes.
