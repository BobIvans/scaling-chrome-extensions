# PR97–PR100 insertion map — Execution Brain V9

No new PR numbers.

## PR97 — ProviderGraph / Cognitive Session Bus

Add:
- TaskClass-level provider/tool success priors;
- provider latency/quota/health;
- world_revision bound to CognitiveSession request/result;
- route feedback receipt.

## PR98 — ChatGPT plan/provider auth

Add:
- provider usage/quota telemetry;
- modality/tool capability discovery;
- cost/plan-opportunity metadata for Value Router.

## PR99 — Cheap/Fast Cognitive Router

This is the primary V9 implementation PR.

Add:
- ExecutionBrainState;
- belief/unknown state;
- Goal Frontier;
- adaptive memory selector;
- contextual Value Router;
- empirical routing stats;
- route regret;
- predictive prefetch;
- anytime cancellation;
- tool-set minimization;
- procedure promotion signal.

The existing deterministic utility scorer can seed priors, but verified outcomes must update them.

## PR100 — Persistent Grok/ChatGPT Relay

Add:
- world_revision on every supervisor/task packet;
- stale-result rejection;
- event-triggered Grok review;
- provider result usefulness feedback;
- strong-call → procedure learning receipt.

## Dependencies

Real benefits require still-planned:
- durable parallel Core;
- Surface/Shadow Workspace;
- Artifact Broker;
- fresh-context rounds;
- local Auditor;
- Dev Workbench / Qualification Ops.
