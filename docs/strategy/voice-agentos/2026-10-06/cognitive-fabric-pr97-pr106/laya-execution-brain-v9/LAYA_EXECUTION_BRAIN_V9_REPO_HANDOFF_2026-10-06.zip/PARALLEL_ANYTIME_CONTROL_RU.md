# Parallel Anytime Control

## Goal

Parallelism should reduce wall-clock time without making the agent wait for every lane.

## Start policy

Start a lane when:
- it is safe and independent;
- expected information/progress value is positive;
- its resource cost fits budget;
- it is likely to be needed soon.

## Stop policy

Cancel/deprioritize when:
- acceptance gap already closed;
- its question was answered by another lane;
- evidence made its route irrelevant;
- provider result will be stale;
- marginal expected value falls below configured threshold.

## Examples

### Research
Library + web + Drive + repo + web3 read-only observations run together.
First exact answer may make public web search unnecessary.

### Grok
Grok can continue strategy analysis while exact data lanes work.
If local evidence fully resolves the blocker, its result can be stored but ignored for current action.

### Context compaction
Compaction/summarization can run in parallel rather than blocking the main execution loop.

## Horizon reduction

Prefer many short verified subtasks to one huge speculative plan.
Recent research on horizon length finds that reducing effective horizon improves stability and generalization in long action sequences.
