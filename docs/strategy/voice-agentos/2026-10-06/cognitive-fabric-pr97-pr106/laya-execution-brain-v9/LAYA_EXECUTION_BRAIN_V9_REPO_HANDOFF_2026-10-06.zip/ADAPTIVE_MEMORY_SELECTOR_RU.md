# Adaptive Memory Selector

## Do not retrieve everything

The correct memory mix depends on the question.

Possible structures:
- raw Library source slices;
- temporal/context graph;
- latest verified state;
- procedure memory;
- failure memory;
- repo/code graph;
- live surface snapshot;
- market/RPC evidence.

## Query-adaptive selection

Before calling Laya/strong AI:
1. classify the active gap;
2. choose memory structures likely to answer it;
3. retrieve bounded evidence;
4. measure context debt;
5. add another structure only if expected information gain justifies it.

## Example

“Why did this flashloan route fail simulation?”

Likely memory:
- simulation log exact slice;
- route JSON;
- current RPC snapshot;
- code symbols;
- prior matching failure signatures.

Probably not:
- whole lifetime conversation history.

## Research signal

MESA reports that a task-adaptive combination of memory structures can outperform always-reading all structures while using fewer evidence tokens.
MAGE treats memory as execution-state management and keeps the active verified branch separate from failed traces.
