# Current runtime truth

Authoring baseline: current main after merged PR62/#63 and docs-only future R&D waves.
Codex must refresh `main` before implementation.

## Already implemented

- canonical local Library: exact captured files, search, annotations/labels, provenance/revisions;
- streamed virtualized browser chat archive with coverage/gaps/order;
- BrowserWatch can enumerate allowed tabs and capture changed content;
- watched local folders and previous AI export ingestion;
- Google Drive API/export ingestion;
- browser tab list and explicit tab-id operations;
- generic browser UI inventory, exact fingerprints and bounded READ_NAV;
- Windows UIA inventory/action fallback;
- human foreground lease/yield;
- Laya client/supervisor;
- FastDecision parallel prefetch across Library/browser/Windows;
- FastDecision can produce a safe parallel-plan *description*;
- durable Goal/H2/H1/H0 and restart resume;
- text-only qualified AI-site bind/prepare/send-once/reconcile primitive;
- Codex System-2 relay primitive;
- capability candidate → tests → PR/CI/exact-head merge primitives.

## Important gaps

1. BrowserWatch currently captures selected tabs sequentially, not as a durable multi-tab lane scheduler.
2. FastDecision parallel plan is not full durable parallel execution.
3. PersistentMission still admits one main H0 at a time.
4. No `LaneRegistry` binding one goal to many tab/app/provider/process lanes.
5. No per-tab/per-conversation durable lease model integrated with mission state.
6. No Grok supervisor heartbeat/checkpoint protocol.
7. No event-triggered escalation policy from Laya to Grok.
8. No evidence fan-in stream that immediately re-ranks/cancels parallel lanes.
9. No multimodal TaskPacket/attachment relay in current text-only AI-site adapter.
10. No provider-neutral ChatGPT/Grok persistent CognitiveSession runtime.
11. No structured WebMCP/CDP capability discovery owner.
12. No Drive UI fallback or generic any-download Artifact Broker.
13. No registered read-only web3 dashboard adapter lifecycle end-to-end.
14. No local Dev Workbench/ConPTY execution surface for Studious Pancake.
15. No real Windows installed long-horizon qualification proving human+agent coexistence.

Conclusion:
the foundations are real, but “Grok thinks while Laya controls parallel tabs until the goal is verified” is not implemented yet.
