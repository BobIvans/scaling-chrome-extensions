# PR97–PR100 insertion map — Parallel Supervisor V8

No new PR numbers.

## PR97 ProviderGraph / Cognitive Session Bus

Add:
- LaneRegistry contract for `AI_THINKER`;
- persistent GrokSupervisor session;
- provider/session exact identity;
- CognitiveRequest/SupervisorPacket state;
- async status/result events.

## PR98 Secure provider auth

Add:
- authorized Grok/ChatGPT/provider session lifecycle;
- quota/health telemetry;
- attachment/task-packet privacy controls.

## PR99 Cheap/Fast Cognitive Router

Add:
- escalation policy;
- EvidenceFanIn listener;
- event-driven Laya re-ranking;
- predicted prefetch;
- cancel obsolete lanes;
- ignore stale Grok results.

## PR100 Persistent Grok/ChatGPT Relay

Add:
- Grok supervisor protocol;
- concurrent local lane execution while provider thinks;
- delta updates;
- TaskPacket/attachment relay from Laya Hands V7;
- response → CognitiveProposal;
- Critic → local ActionCandidates;
- session timeline.

## Required earlier foundations

True multi-tab/action parallelism also depends on the still-planned:
- PR64 durable parallel Core execution;
- PR70/71 SurfaceGraph + Shadow Workspace;
- PR89 fresh-context rounds;
- PR91 Dev Workbench for process lanes.

Codex must implement missing prerequisites rather than faking V8 on serial execution.
