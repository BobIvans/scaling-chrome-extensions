# Grok Supervisor Protocol

## Persistent Grok Supervisor Session

One optional long-lived Grok session can act as mission strategist/critic.

It keeps:
- GoalContract summary;
- verified milestone summaries;
- unresolved blockers;
- strategy hypotheses;
- prior supervisor recommendations.

It does **not** need every low-level click or full transcript.

## SupervisorPacket

Sent only on escalation:

- goal_id / active subgoal;
- acceptance still open;
- verified progress since last Grok review;
- new high-value evidence;
- contradictions;
- failed strategies / no-progress counters;
- active lanes;
- available capabilities;
- exact question for Grok;
- requested output schema;
- prohibited effects.

## GrokSupervisorProposal

Expected fields:
- strategic assessment;
- most likely blocker;
- proposed next evidence;
- proposed strategy change;
- proposed code/capability gap;
- risk flags;
- what would falsify the recommendation;
- optional TaskPackets for deeper subresearch.

## Integration rule

Grok recommendation:
→ CriticHand
→ code-generated candidates
→ Laya route selection
→ Core admission
→ local Auditor.

Never:
`Grok text → direct click/shell/wallet/Git effect`.

## Asynchronous operation

While Grok thinks:
- tab researchers continue;
- Library/Drive harvest continues;
- RPC/DEX observers continue;
- simulations/tests continue;
- Laya can execute already-known safe steps.

When Grok returns, only still-relevant recommendations are considered.
Stale recommendations are discarded if the verified world state changed materially.
