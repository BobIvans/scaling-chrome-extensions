# What Laya / AgentOS should be skilled to do out of the box

This catalog distinguishes current foundation from the intended out-of-box product.

## Already largely available now

### Observe
- list browser tabs;
- capture current/selected browser content;
- archive long virtualized AI chats with coverage/gaps;
- inspect generic browser UI;
- inspect Windows UIA surface;
- yield when the human owns foreground UI.

### Store
- import captured files into Local Library;
- search Library;
- attach labels/annotations;
- watch local folders;
- ingest supported Google Drive files through API/export;
- ingest previous conversation exports.

### Decide
- Laya typed decisions;
- parallel Library/browser/Windows prefetch;
- utility-ranked route;
- durable Goal/H2/H1/H0;
- restart pending System-2/Core jobs.

### Basic effects
- safe generic browser READ_NAV;
- safe Windows READ_NAV;
- text-only qualified AI-site draft/readback/send-once/reconcile primitive;
- Codex relay;
- isolated capability patch/tests/PR/CI flow primitives.

## Intended out-of-box after planned implementation

### Universal knowledge
- “find everything we know about X”;
- harvest Drive/UI/browser/downloads/AI sessions;
- automatically organize source/type/project/time/provenance;
- build bounded evidence/context packs.

### Browser research
- open/duplicate research tabs;
- compact snapshot/delta observation;
- follow sources;
- download artifacts;
- use WebMCP/API/CDP/DOM before pixels;
- work in background while user remains foreground.

### AI collaboration
- Continue in Grok;
- Continue in ChatGPT;
- send text/document/image/mixed TaskPackets;
- maintain persistent thinking session;
- archive every turn;
- use returned proposal only after local compilation/verification.

### Long-horizon execution
- multiple durable lanes;
- first-useful-evidence replanning;
- Grok strategic supervision;
- fresh-context rounds;
- independent audit;
- crash/restart recovery.

### Development
- registered terminal/process sessions;
- repo/files/git/log inspection;
- code worker;
- tests/replay;
- PR/CI;
- staged self-update;
- resume original mission.

### Web3 / flashloan
- read-only authorized dashboard observation;
- gather pair/pool/liquidity/fee/quote evidence;
- run RPC/DEX health;
- simulation/replay/paper qualification;
- ask Grok/Codex for novel diagnosis;
- learn reusable dashboard/data procedures.

### Learning
- successful AI-discovered route → procedure;
- drift detection;
- repair only when needed;
- provider/capability success statistics.
