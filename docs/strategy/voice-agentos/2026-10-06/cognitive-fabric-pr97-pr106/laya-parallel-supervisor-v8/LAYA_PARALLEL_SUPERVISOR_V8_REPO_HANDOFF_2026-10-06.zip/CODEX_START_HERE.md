# Codex Start Here — Laya Parallel Supervisor V8

This is an implementation addendum to PR97–PR100.

Do not create another new architecture before coding these foundations.

Before V8:
- re-audit current main;
- implement missing durable parallel Core and Surface/Shadow prerequisites.

When PR97–PR100 are implemented:
- add LaneRegistry;
- add GrokSupervisor session;
- add EvidenceFanIn;
- add event-triggered escalation;
- add stale-result rejection;
- keep local Auditor as success authority.

Critical safety:
- external AI prose never executes directly;
- same remote composer/form remains one-writer even across duplicate tabs;
- human foreground ownership wins;
- flashloan qualification remains non-live by default.
