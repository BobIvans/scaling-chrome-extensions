# Parallel Supervisor Architecture

## Roles

### Laya Fast Supervisor
Runs frequently and cheaply.
Responsibilities:
- choose active goal gap;
- select safe lanes;
- rank new evidence;
- decide whether strong reasoning is actually needed;
- stop/cancel obsolete lanes;
- compile bounded ActionCandidate choices.

### Grok Deep Supervisor
Runs rarely/event-driven.
Responsibilities:
- challenge current strategy;
- synthesize novel evidence;
- reason about unfamiliar protocols/apps;
- diagnose repeated failures;
- propose code/research plans;
- review whether the mission appears strategically on track.

Grok does **not** prove task success and does not own effects.

### Lane Workers

- TAB_OBSERVER
- TAB_RESEARCHER
- TAB_EXECUTOR
- WINDOWS_OBSERVER
- WINDOWS_EXECUTOR
- LIBRARY_RETRIEVER
- DRIVE_HARVESTER
- WEB_RESEARCHER
- RPC_DATA
- DEX_DATA
- PROCESS
- CODE_WORKER
- AI_THINKER
- AUDITOR

Each lane has exact resources, scope, effect class and verifier.

### Local Auditor

Owns ground-truth verification:
- browser/app state;
- files;
- downloads;
- Git diff;
- tests;
- process/log state;
- RPC responses;
- simulation/paper receipts.

Only Auditor-accepted progress enters trusted Goal state.

## Event-driven architecture

Parallel lanes emit events into `EvidenceFanIn`.

Examples:
- NEW_SOURCE
- NEW_ARTIFACT
- TAB_DELTA
- PROCESS_EXIT
- TEST_RESULT
- RPC_SNAPSHOT
- SIMULATION_RESULT
- AI_PROPOSAL
- CONTRADICTION
- SURFACE_DRIFT
- NO_PROGRESS
- UNKNOWN_EFFECT

Laya re-ranks on meaningful events.

Grok is called only on configured escalation events.

## Supervisor cadence

Do not poll Grok every few seconds.

Grok review happens:
- at initial hard-goal strategy creation;
- after a novel/unknown surface or protocol;
- after repeated verified no-progress;
- when evidence materially contradicts the current strategy;
- before a high-consequence strategy pivot;
- when a code/capability gap needs design;
- at milestone/final strategic review.

Routine page navigation, downloads, data reads and known procedures remain Laya/EXACT.
