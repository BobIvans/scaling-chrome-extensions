# Flashloan Parallel Mission Example

User:
"Continue flashloan qualification and find the highest-value next experiment."

## Initial lanes

L1 Library:
retrieve previous decisions, failed routes, prior qualification receipts.

L2 Repo:
read current branch/architecture/tests.

L3 RPC:
health/freshness/state snapshots.

L4 DEX/API:
quotes/liquidity/routes from configured sources.

L5 Web3 UI:
authorized read-only dashboard evidence where API coverage is missing.

L6 Simulation:
run registered simulation/replay when prerequisites are present.

L7 Grok Supervisor:
receive strategic packet only if current phase is novel/uncertain.

L8 Auditor:
verify test/simulation/data receipts.

## Event flow

DEX lane discovers new pair
→ EvidenceFanIn
→ Laya checks whether route criteria are satisfied
→ RPC prefetch starts
→ UI dashboard lane gathers missing displayed fees
→ simulator starts when exact state ready.

If simulator fails with unknown signature:
→ local log classification
→ if no known recovery:
   escalate compact packet to Grok/Codex
→ code/strategy proposal
→ isolated patch/research candidate
→ tests/replay
→ Auditor
→ progress.

## Grok review does not block safe work

While Grok reasons:
- API/RPC collection continues;
- historical context retrieval continues;
- safe tab observations continue;
- simulation prerequisites can be prepared.

## Qualification boundary

Default:
- simulation/replay/paper;
- live trading disabled;
- wallet signing/transaction submission not part of research/qualification supervisor.
