# ALL-IN-ONE — Long-Horizon Meta-Control PR88–PR96


---

## FILE: `CODEX_ONE_LINE.txt`

Open current main and read CODEX_LONG_HORIZON_META_CONTROL_START_HERE.md plus docs/strategy/voice-agentos/2026-10-06/long-horizon-meta-control-pr88-pr96/; do not skip unfinished PR64–PR87 prerequisites, reuse the canonical Core/Goal/resource/effect/Library/Surface owners, and implement the earliest missing dependency with code/tests/receipts, using fresh-context verified rounds and keeping the Studious Pancake qualification profile simulation/paper-only unless a separate live capability is explicitly qualified.


---

## FILE: `CODEX_TASKS_PR88_PR96.json`

{
  "schema": "voice-agentos.pr88-pr96-codex-tasks.v1",
  "start_rule": "Re-audit current main and implement the earliest missing prerequisite, not necessarily PR88 if PR64–PR87 remain unfinished.",
  "implementation_rules": [
    "Reuse canonical Core, jobs, workflow_state, Goal, effect, Library and Surface owners.",
    "No second queue or DB.",
    "Tests before consequential wiring.",
    "Model/page text is untrusted data.",
    "Persist exact receipts and independent verification.",
    "Do not enable live financial effects in the qualification profile."
  ],
  "first_future_pr_expected_owners": [
    "content-lab/goal_runtime.py",
    "content-lab/workflow_state.py",
    "content-lab/automation_core.py",
    "local-agent/persistent_mission.py",
    "local-agent/mini_controller.py"
  ]
}


---

## FILE: `COMMAND_SPEC_SCHEMA.json`

{
  "schema": "voice-agentos.command-spec.v1",
  "command_id": "identifier",
  "workspace_id": "identifier",
  "argv": [
    "exact",
    "argv",
    "tokens"
  ],
  "cwd": "workspace-relative or policy-bound absolute path",
  "env_allowlist": [
    "NAME"
  ],
  "credential_scopes": [
    "optional credential capability id"
  ],
  "effect_class": "LOCAL_READ|LOCAL_PROCESS|LOCAL_WRITE|NETWORK_READ|NETWORK_WRITE|GIT_WRITE",
  "resources": [
    "workspace:repo",
    "process:...",
    "port:..."
  ],
  "timeout_seconds": 600,
  "interactive": false,
  "expected_outputs": [
    "file/test/log/process/network postconditions"
  ],
  "verifier_id": "registered verifier",
  "retry_policy": "NONE|VERIFY_NO_EFFECT_THEN_RETRY",
  "stop_behavior": "terminate process tree and reconcile"
}


---

## FILE: `FLASHLOAN_QUALIFICATION_OPS_RU.md`

# Studious Pancake — Qualification Campaign Operations

## Yes: target product behavior

After the required execution layers are implemented, the user should be able to point AgentOS at the `studious-pancake` workspace and say:

> "Run the next flashloan qualification phase, gather the relevant market/RPC/DEX evidence, execute tests/simulations/paper runs, analyze failures, ask Codex/System-2 only where useful, and prepare the next verified change."

AgentOS should operate the workspace through the same durable mission system.

## Qualification profile — default boundary

The qualification profile must default to:
- `live_trading_enabled = false`;
- no live wallet/transaction submission;
- no hidden credential use;
- simulations, replay, paper/evidence collection allowed only through registered commands/capabilities.

Live financial execution must be a separate explicitly qualified capability and is **not** implied by campaign success.

## Campaign phases

Q0 Environment preflight
- repo SHA/status;
- Python/Node/Rust/tool versions;
- configured data sources;
- RPC reachability;
- credentials present only as scoped capability state;
- disk/log capacity.

Q1 Context build
- prior flashloan conversations;
- repo architecture/function graph;
- previous qualification receipts;
- source/address/config registry;
- unresolved failures.

Q2 Data-source health
- prices/quotes;
- RPC;
- DEX/aggregators;
- Jito/other execution infrastructure if configured;
- latency/rate/error receipts;
- freshness.

Q3 Candidate discovery
- routes/pairs/amount ranges;
- observation graph;
- dedupe;
- candidate reason.

Q4 Verification
- exact RPC/on-chain state reads;
- fees/slippage/constraints;
- stale-route rejection.

Q5 Simulation/replay
- deterministic fixtures where possible;
- transaction simulation;
- historical replay;
- failure classification.

Q6 Paper qualification
- no-value-at-risk execution;
- predicted vs observed;
- latency;
- opportunity decay;
- profitability after modeled costs;
- false-positive rate.

Q7 Engineering loop
- create minimal repro;
- call Codex/System-2 if code change needed;
- patch;
- tests;
- diff audit;
- replay qualification.

Q8 Acceptance report
- what passed;
- what failed;
- exact evidence;
- open blockers;
- next recommended experiment;
- no unsupported production/live claim.

## Parallel lanes

Examples:
- Library/repo context read;
- data-source health;
- RPC verification;
- market graph analysis;
- simulation;
- independent verifier;
- Codex code analysis.

Mutable repo writes and mutable execution/wallet resources stay one-writer.

## UI

Flashloan Qualification tab:
- Campaign phase
- Data Sources
- Routes/Candidates
- Simulations
- Paper Runs
- Command Sessions
- Logs
- Evidence
- Failures
- Metrics
- Next Experiment
- STOP


---

## FILE: `HORIZON_GRAPH_SCHEMA.json`

{
  "schema": "voice-agentos.horizon-graph.v1",
  "goal_id": "string",
  "revision": "int",
  "subgoals": [
    {
      "id": "identifier",
      "parent": "optional identifier",
      "depends_on": [
        "identifier"
      ],
      "state": "PROPOSED|ACTIVE|BLOCKED|VERIFIED|INVALIDATED",
      "acceptance_ids": [
        "identifier"
      ],
      "context_scope": [
        "source refs / entity ids / workspace ids"
      ],
      "resource_scope": [
        "resource ids"
      ],
      "strategy_id": "optional",
      "round_ids": [
        "round ids"
      ]
    }
  ],
  "edges": [
    {
      "from": "subgoal id",
      "to": "subgoal id",
      "kind": "DEPENDS_ON|UNLOCKS|ALTERNATIVE|CONTRADICTS"
    }
  ]
}


---

## FILE: `IMPLEMENTED_VS_MISSING_RU.md`

# Implemented vs Missing — authoring audit

Baseline to re-audit before coding: `main@4c73781b5205fc769abd58b0a834372765d2155d`.

## Already present in code / previous R&D

- local Library, raw context, versions/provenance, search/labels;
- streamed virtualized browser chat archive;
- BrowserWatch and local folder/AI-export ingestion;
- Google Drive API/export ingestion;
- browser tab/UI inventory and READ_NAV broker;
- Windows UIA fallback and human foreground lease;
- Laya client/supervisor;
- FastDecision parallel read prefetch;
- durable Goal/H2/H1/H0 + restart resume;
- AI-site exact identity, draft readback, send-once and reconcile primitive;
- capability candidate/PR/CI/merge pipeline;
- release/update staging primitives;
- PR64–PR87 R&D packages for durable parallel execution, SurfaceGraph, Shadow workspace, artifact broker, JIT memory, Laya V3, executor ladder, trajectory memory and evals.

## Still missing for the user’s long-horizon / flashloan command-center vision

1. Fresh-context round engine with independent Manager/Executor/Auditor roles.
2. Explicit HorizonGraph that isolates subtask contexts and error recovery.
3. Uncertainty/Evidence ledger with expected-value-of-information question policy.
4. Strategy portfolio with controlled exploration, pre-mortem and pivot rules.
5. Dynamic skill loading/negative-transfer guard; loading “all skills” is unsafe and expensive.
6. Process-level judge that refuses to accept model claims without artifacts/logs/tests/UI receipts.
7. Durable interactive local command/process surface for arbitrary *registered/authorized* qualification commands.
8. Windows ConPTY/PTY session owner, process tree, logs, exit state, stop/cancel/reconcile.
9. Dev Workbench in the local app: terminal, workspace, files, git diff, logs, tasks, services, approvals.
10. VS Code bridge / open-workspace integration. A full VS Code fork is not required for the first reliable implementation.
11. Workspace identity/resource leases so repo-A commands cannot mutate repo-B.
12. Qualification profile for Studious Pancake that safely runs tests, data collectors, RPC/DEX research, simulations and paper/replay jobs.
13. Unified data-source/process telemetry ingestion into Library/Timeline.
14. Flashloan campaign phase graph with explicit NO_LIVE_TRADING qualification default.
15. Dense progress/credit assignment for multi-hour tasks.
16. Context folding after verified subgoal completion.
17. Round recovery after model context refresh, crash, sleep, network loss or process orphan.
18. 24h+ long-horizon Windows qualification with measurable interruption/progress/failure metrics.


---

## FILE: `LAYA_RAILWAY_V4_QUESTION_LIBRARY.json`

{
  "schema": "voice-agentos.laya-railway-v4-questions.v1",
  "principles": [
    "Code generates candidate IDs; Laya chooses/scores/abstains.",
    "Question passes are activated conditionally.",
    "Safe observation is preferred to human interruption.",
    "Only independently verified progress enters durable accepted state.",
    "Subtasks receive scoped fresh context.",
    "Skills/tools are loaded minimally, not globally.",
    "Consequential actions are preflighted and revalidated."
  ],
  "passes": {
    "frame_selection": [
      "active_frame_ids:allowed_ids",
      "long_horizon:noul",
      "consequence_level:score",
      "fresh_context_round_needed:noul"
    ],
    "outcome": [
      "acceptance_gap:choice",
      "terminal_state_verifiable:noul",
      "goal_drift_detected:noul"
    ],
    "uncertainty": [
      "blocking_uncertainty:choice",
      "uncertainty_kind:choice",
      "safe_observation_can_resolve:noul",
      "human_question_value:score"
    ],
    "horizon": [
      "active_subgoal:choice",
      "subgoal_isolated:noul",
      "independent_lane_ids:allowed_ids",
      "fold_completed_context:noul"
    ],
    "strategy": [
      "strategy_choice:choice",
      "success_prior:score",
      "failure_risk:score",
      "latency_cost:score",
      "pivot_trigger:choice"
    ],
    "skill_gate": [
      "required_capability_ids:allowed_ids",
      "skill_negative_transfer_risk:score",
      "minimal_skill_set_sufficient:noul"
    ],
    "action": [
      "action_candidate:choice",
      "expected_progress:score",
      "expected_information_gain:score",
      "wrong_target_risk:score",
      "counterfactual_preview_needed:noul"
    ],
    "verification": [
      "verification_candidate:choice",
      "executor_claim_sufficient:noul",
      "ground_truth_observed:noul",
      "progress_accept:choice"
    ],
    "recovery": [
      "failure_class:choice",
      "effect_may_be_unknown:noul",
      "reobserve_before_retry:noul",
      "recovery_route:choice"
    ],
    "termination": [
      "all_acceptance_verified:noul",
      "unknown_effects_resolved:noul",
      "deliverable_usable:noul",
      "next_disposition:choice"
    ]
  }
}


---

## FILE: `LOCAL_DEV_WORKBENCH_RU.md`

# Local Dev Workbench — command line / VS Code coexistence

## Recommendation

Do **not** fork VS Code first.

A VS Code fork is a large maintenance surface and does not itself improve execution reliability.
Build the execution authority in AgentOS, then expose it through:
- an integrated terminal/process panel;
- workspace/file/git/log views;
- a normal VS Code bridge that opens the same workspace for human editing;
- optional lightweight VS Code extension later for deep-linking/highlights/context sync.

## Command architecture

A model never sends an unrestricted shell string straight to `cmd.exe` or PowerShell.

It proposes a `CommandSpec`.

The local Core validates:
- workspace identity;
- argv;
- cwd;
- allowed environment variables;
- network/effect class;
- timeout;
- resource locks;
- expected outputs;
- verifier;
- cancellation policy.

## Windows implementation

- ConPTY owner for interactive sessions;
- noninteractive subprocess owner for deterministic jobs;
- process tree tracking;
- PID + start time + executable identity;
- stdout/stderr streaming;
- bounded log persistence;
- STOP/cancel process-tree kill;
- orphan detection;
- restart/reconciliation;
- working-directory/resource lease;
- no secret inheritance except explicitly scoped credentials.

## UI panels

Mission | Terminal | Files | Git | Logs | Processes | Data | Artifacts | Approvals | Replay

Buttons:
- Run Qualified Command
- Open Workspace in VS Code
- New Agent Terminal
- Attach Existing Process
- Stop Process
- Verify Outputs
- Save Procedure
- Re-run in Replay/Sandbox

## VS Code bridge

First version:
- open/reuse workspace with `code --reuse-window`;
- open exact file/line through CLI/URI;
- import current git diff/status into Mission Timeline;
- AgentOS remains authority for commands/effects.

A future extension may:
- show active Goal/H2/H1/H0;
- show AgentOS approvals;
- send selection/file context to Library;
- highlight files changed by current lane.


---

## FILE: `MASTER_CONTEXT_RU.md`

# Master Context — Long-Horizon Meta-Control

## User outcome

The local app should let the user say one goal and then coordinate permitted context gathering and execution across:
- lifetime local Library;
- previous AI conversations;
- Google Drive/API/UI documents;
- arbitrary allowed web pages/downloads;
- Chrome tabs;
- Windows 11 apps;
- repositories and Git;
- terminals/commands;
- Codex/other AI providers;
- Studious Pancake flashloan qualification workflows.

The system should maximize verified success probability, not merely maximize autonomy.

## What “highest success probability” means here

There is no universal mathematical guarantee that any agent will achieve the highest possible success rate on arbitrary tasks. The engineering target is instead:

1. calibrated capability-specific success priors;
2. minimal wrong-target and duplicate-effect rates;
3. dense verified progress signals;
4. local recovery instead of global drift;
5. fresh context for each bounded subtask;
6. independent ground-truth audit;
7. explicit stop/pivot criteria;
8. empirical replay/eval promotion.

## Long-horizon failure modes to design against

- goal drift;
- stale context;
- monolithic plans;
- error propagation across unrelated subtasks;
- premature “done” claims;
- context-window exhaustion;
- skill negative transfer;
- repeating failed actions;
- hidden environment drift;
- wrong workspace/account/tab;
- unverified command success;
- orphaned processes;
- unknown external effects;
- humans and agents fighting for the same UI;
- plan persistence without verified progress.

## Target round architecture

Manager / Meta-controller:
- reconstruct original goal;
- load only verified progress;
- select active subgoal and mental frames;
- produce a bounded execution brief.

Executor:
- receives fresh scoped context;
- performs one bounded operation or coherent batch;
- returns observations/receipts, not self-certified success.

Auditor:
- independently inspects files/UI/logs/tests/receipts;
- either accepts progress or produces failure evidence.

Only audited progress is folded into durable state.

## Relation to existing H2/H1/H0

Do not replace H2/H1/H0.

Add:
- `HorizonGraph`: subgoal dependencies / independent branches / phase state;
- `RoundLedger`: fresh-context execution rounds;
- `UncertaintyLedger`: unresolved facts and expected value of information;
- `VerificationLedger`: accepted/rejected progress;
- `ProcessLedger`: terminal/process state;
- `StrategyPortfolio`: alternate approaches and pivot history.

These should extend existing canonical Goal/Core records.


---

## FILE: `MENTAL_FRAME_RAILWAY_V4_RU.md`

# Mental Frame Railway V4

A “mental frame” is a typed code-level decision contract, not hidden free-form chain-of-thought.

The meta-controller activates only the frames needed for the current edge.

## F0 — Authority Frame
Questions:
- What effects are permitted?
- Which resources are human-owned right now?
- Which actions require approval?
Output: immutable effect/resource envelope for this round.

## F1 — Outcome Frame
- What observable terminal state proves success?
- Which acceptance clauses remain open?
- What must never happen?
Output: current outcome contract.

## F2 — Reality Frame
- What is *verified* now?
- What changed since the last accepted checkpoint?
- Are workspace/account/tab/process identities fresh?
Output: verified state snapshot.

## F3 — Uncertainty Frame
- What unknown most blocks the next useful action?
- Is it user intent, missing evidence, environment state, capability, or outcome uncertainty?
Output: ranked uncertainty IDs.

## F4 — Information-Gain Frame
- Can a cheap safe read resolve the uncertainty?
- Is asking the user more valuable than observing/retrieving?
Output: evidence acquisition action or bounded human question.

## F5 — Horizon Frame
- Which H2 milestone/subgoal is active?
- Which branches are independent?
- Which subgoal context can be isolated?
Output: HorizonGraph scope for the round.

## F6 — Strategy Portfolio Frame
For hard tasks only:
- generate 2–4 materially different strategies;
- estimate calibrated success, latency, risk, resource needs and reversibility;
- preserve alternatives until evidence discriminates.
Output: selected strategy + backups.

## F7 — Pre-mortem Frame
For consequential/long tasks:
- choose likely failure classes from a code-generated taxonomy;
- attach mitigations and early warning signals.
Output: risk probes / guardrails.

## F8 — Resource & Parallel Frame
- which actions can safely run concurrently?
- which share mutable resources?
- what can continue while the human works?
Output: lane set + one-writer leases.

## F9 — Skill / Tool Frame
- which qualified skills/tools are relevant?
- could a skill introduce negative transfer?
- should the minimal tool subset be loaded?
Output: scoped capability set.

## F10 — Action Frame
Code generates bounded ActionCandidates with:
target, effect, resources, expected postcondition, verifier, rollback/reconcile route.
Laya chooses among IDs or abstains.

## F11 — Counterfactual Frame
For risky/expensive actions:
- what state delta should this action produce?
- does it improve the current subgoal?
- is a safer action equivalent?
Output: predicted delta + admit/reject.

## F12 — Commit Frame
- revalidate exact target;
- acquire resources;
- record EffectIntent if needed;
- dispatch once.
Output: effect/process receipt.

## F13 — Verification Frame
Independent Auditor checks actual environment:
files, git diff, tests, logs, UI, downloads, process state, network/RPC receipts.
Output: ACCEPT / REJECT / UNKNOWN.

## F14 — Progress/Credit Frame
- which acceptance/subgoal clauses closed?
- what exact evidence caused progress?
- which lanes became obsolete?
Output: ProgressDelta with credit to actions/evidence.

## F15 — Recovery/Pivot Frame
On reject/no-progress:
- classify failure;
- retry only if postcondition proves no effect;
- repair capability, change strategy, ask System-2, or ask human.
Output: localized recovery plan.

## F16 — Context Folding Frame
After accepted subgoal:
- preserve raw artifacts;
- summarize verified result and unresolved edges;
- remove irrelevant trajectory noise from next executor context.
Output: folded verified state.

## F17 — Procedure Learning Frame
- is this trajectory reusable?
- record high-level blueprint and low-level procedure;
- replay before promotion.
Output: staged procedural memory.

## F18 — Termination/Audit Frame
- are all acceptance clauses independently verified?
- are UNKNOWN effects/resources resolved?
- are deliverables usable?
Output: verified completion or explicit remaining work.

## Rule

Long tasks should not run one enormous LLM conversation.
They should run many bounded verified rounds over one durable goal.


---

## FILE: `PR88_LONG_HORIZON_META_CONTROLLER_RU.md`

# PR88 — Long-Horizon Meta-Controller + HorizonGraph

Implement:
- MentalFrameState;
- conditional frame activation;
- HorizonGraph in canonical Goal runtime;
- subgoal context/resource scopes;
- StrategyCard store;
- pivot history;
- pre-mortem taxonomy;
- no new mission DB.

Tests:
- independent subgoal failure does not invalidate unrelated verified subgoal;
- goal revision invalidates affected branches only;
- long task can reconstruct active subgoal after restart;
- no-progress triggers Recovery/Pivot frame, not infinite loop.


---

## FILE: `PR89_FRESH_CONTEXT_ROUND_ENGINE_RU.md`

# PR89 — Fresh-Context Round Engine

Implement Manager/Executor/Auditor role boundaries around current Core:
- Manager builds bounded execution brief from original goal + verified state + failures;
- Executor receives fresh scoped ContextPack and one bounded objective;
- Auditor independently checks ground truth;
- only accepted progress enters durable Goal;
- completed subgoal trajectory is folded.

Allow same or different provider/backend per role.

Tests:
- executor claim without audit is not durable progress;
- rejected round feeds failure evidence to next manager round;
- context refresh does not lose original goal or verified checkpoints;
- unrelated subgoal context is not leaked by default.


---

## FILE: `PR90_UNCERTAINTY_EVIDENCE_QUESTION_POLICY_RU.md`

# PR90 — Uncertainty/Evidence Ledger

Implement:
- typed Unknown records;
- source/evidence candidates;
- expected information gain;
- human interruption cost;
- safe-observation-first policy;
- question budget;
- question outcome receipt.

Goal: the user states the task once and is interrupted only when human intent/authority is genuinely required.


---

## FILE: `PR91_LOCAL_DEV_WORKBENCH_CONPTY_RU.md`

# PR91 — Local Dev Workbench + Durable Terminal/ConPTY

Implement local AgentOS execution surface:
- workspace registry/identity;
- CommandSpec validation;
- noninteractive subprocess jobs;
- ConPTY interactive sessions on Windows;
- process tree / PID / executable/start-time binding;
- logs;
- cancellation/STOP/orphan reconciliation;
- git/file/process panels;
- VS Code open-workspace/file bridge;
- optional future VS Code extension, not a fork requirement.

Never execute arbitrary raw shell text from page/model output.


---

## FILE: `PR92_STUDIOUS_PANCAKE_QUALIFICATION_OPS_RU.md`

# PR92 — Studious Pancake Qualification Ops Runtime

Implement a domain profile on top of AgentOS, not a separate bot manager.

Capabilities:
- workspace preflight;
- run registered tests/build commands;
- start/stop data collectors;
- inspect logs;
- market/RPC/source health receipts;
- route/candidate ingestion;
- transaction simulation/replay;
- paper qualification;
- Codex repair lane;
- campaign report.

Default qualification policy:
`live_trading_enabled=false`.

Live transaction authority is not created by this PR.


---

## FILE: `PR93_STRATEGY_PORTFOLIO_PIVOT_RU.md`

# PR93 — Strategy Portfolio / Pre-mortem / Pivot

Implement StrategyCards and controlled exploration.

Hard task:
- keep 2–4 materially different routes;
- run cheap discriminating experiments;
- update empirical success priors;
- pivot on falsified assumptions/no-progress;
- preserve verified progress.

Do not multiply plans on trivial tasks.


---

## FILE: `PR94_SKILL_TOOL_GATING_RU.md`

# PR94 — Skill/Tool Gating + Differential Evaluation

Implement:
- SkillCard reliability/cost/failure metadata;
- minimal dynamic retrieval;
- no-skill/reference replay;
- negative-transfer attribution;
- quarantine/promotion;
- bounded tool context.

No skill text can grant effects.


---

## FILE: `PR95_PROCESS_AUDITOR_DENSE_PROGRESS_RU.md`

# PR95 — Independent Process Auditor + Dense Progress

Implement trajectory-aware audit:
- inspect files/UI/logs/tests/processes/artifacts;
- acceptance-level evidence;
- round-level progress metrics;
- action credit assignment;
- premature-done rejection;
- fake/irrelevant evidence detection where deterministic checks exist.

Expose audit timeline in Mission Cockpit.


---

## FILE: `PR96_LONG_HORIZON_FINAL_QUALIFICATION_RU.md`

# PR96 — 24h+ Long-Horizon Windows/GUI/CLI Qualification

Run real installed campaigns covering:
- browser + CLI + code + files;
- Windows app switching;
- human takeover/release;
- context refresh;
- model/backend swap;
- sleep/restart;
- process orphan;
- network failure;
- quota failure;
- unknown effect;
- mid-run user instruction;
- Studious Pancake qualification campaign.

Measure:
- task completion;
- accepted subgoal rate;
- time-to-first-useful-evidence;
- human interruptions;
- context bytes/model calls;
- recovery success;
- wrong-target effects;
- duplicate effects;
- unreconciled UNKNOWN effects;
- foreground interference;
- total wall-clock and useful-progress efficiency.

Do not claim universal reliability from one successful run.


---

## FILE: `PROCESS_AUDITOR_DENSE_PROGRESS_RU.md`

# Independent Process Auditor and Dense Progress Signals

Outcome-only judging is insufficient for long-horizon work.

## Auditor inputs

- exact task/acceptance;
- current verified checkpoint;
- files/diffs;
- test output;
- process exit/logs;
- UI state;
- downloads/artifacts;
- network/RPC receipts;
- action/effect ledger;
- command/process receipts.

## Auditor does not trust

- Executor "done" text;
- an AI-generated report without source evidence;
- a process exit code when the postcondition is a changed external/UI state;
- a screenshot when exact filesystem/API evidence is required.

## Dense signals

Each round emits:
- subgoal progress delta;
- acceptance clauses closed;
- evidence quality;
- target correctness;
- side-effect correctness;
- regression count;
- efficiency/latency;
- context relevance;
- recovery reason if rejected.

These signals make long-horizon drift visible before the terminal task fails.


---

## FILE: `README.md`

# Voice AgentOS — Long-Horizon Meta-Control / Qualification Ops PR88–PR96

This is a future completion wave after the PR64–PR87 foundations.

It does **not** mean PR64–PR87 may be skipped. Codex must always re-audit `main` and implement the first missing dependency.

The purpose of this pack is to increase long-horizon reliability by engineering the loop around Laya/System-2:

`goal → verified state → active mental frames → bounded subgoal → fresh scoped context → action → independent verification → checkpoint/recover → context fold → repeat`

Start in this order:
1. `MASTER_CONTEXT_RU.md`
2. `IMPLEMENTED_VS_MISSING_RU.md`
3. `MENTAL_FRAME_RAILWAY_V4_RU.md`
4. `LAYA_RAILWAY_V4_QUESTION_LIBRARY.json`
5. `LOCAL_DEV_WORKBENCH_RU.md`
6. `FLASHLOAN_QUALIFICATION_OPS_RU.md`
7. current PR spec.

Core invariant: one canonical durable Core, Goal runtime, resource/effect authority, Library, SurfaceGraph and capability system. Do not create a competing agent database or queue.


---

## FILE: `RESEARCH_SOURCE_LEDGER.json`

{
  "schema": "voice-agentos.long-horizon-research-ledger.v1",
  "sources": [
    {
      "name": "WeaveBench",
      "url": "https://www.microsoft.com/en-us/research/publication/weavebench-a-long-horizon-real-world-benchmark-for-computer-use-agents-with-hybrid-interfaces/",
      "role": "hybrid GUI/CLI/code long-horizon benchmark"
    },
    {
      "name": "The Horizon Gap",
      "url": "https://arxiv.org/abs/2608.06663",
      "role": "2026 survey of planning/memory/execution/evaluation"
    },
    {
      "name": "HIPIF",
      "url": "https://arxiv.org/abs/2606.10507",
      "role": "hierarchical planning + information folding"
    },
    {
      "name": "Task-Decoupled Planning",
      "url": "https://arxiv.org/abs/2601.07577",
      "role": "scoped subtask contexts/local recovery"
    },
    {
      "name": "LongHorizon-Harness",
      "url": "https://github.com/AMAP-ML/LongHorizon-Harness",
      "role": "fresh-context Manager/Executor/Auditor loop"
    },
    {
      "name": "MementoGUI",
      "url": "https://huggingface.co/papers/2605.18652",
      "role": "active long-horizon GUI memory control"
    },
    {
      "name": "MemGym",
      "url": "https://www.microsoft.com/en-us/research/publication/memgym-a-long-horizon-memory-environment-for-llm-agents/",
      "role": "agent memory evaluation"
    },
    {
      "name": "Agent Skills Can Be Harmful",
      "url": "https://www.microsoft.com/en-us/research/publication/agent-skills-can-be-harmful-an-empirical-study-of-skill-induced-failures-in-llm-agents/",
      "role": "negative skill transfer"
    },
    {
      "name": "OpenHands Agent architecture",
      "url": "https://github.com/OpenHands/docs/blob/main/sdk/arch/agent.mdx",
      "role": "tool/context/security execution loop"
    },
    {
      "name": "OpenHands Agent Canvas",
      "url": "https://github.com/OpenHands/docs/blob/main/openhands/usage/agent-canvas/overview.mdx",
      "role": "UI separated from execution backend"
    },
    {
      "name": "Magentic-UI",
      "url": "https://www.microsoft.com/en-us/research/publication/magentic-ui-report/",
      "role": "human-agent collaboration/action guards"
    },
    {
      "name": "WindowsWorld",
      "url": "https://github.com/HITsz-TMG/WindowsWorld",
      "role": "cross-app Windows process benchmark"
    }
  ]
}


---

## FILE: `ROADMAP_PR88_PR96.json`

{
  "schema": "voice-agentos.long-horizon-meta-control-roadmap.v1",
  "authoring_baseline": "main@4c73781b5205fc769abd58b0a834372765d2155d",
  "pr_sequence": [
    {
      "pr": 88,
      "title": "Long-Horizon Meta-Controller + HorizonGraph",
      "purpose": "mental-frame activation, subgoal isolation, strategy/pivot state"
    },
    {
      "pr": 89,
      "title": "Fresh-Context Round Engine + Manager/Executor/Auditor",
      "purpose": "bounded rounds, context folding, independent verification"
    },
    {
      "pr": 90,
      "title": "Uncertainty/Evidence Ledger + Question Value Policy",
      "purpose": "ask only high-value questions, safe observation first"
    },
    {
      "pr": 91,
      "title": "Local Dev Workbench + Durable Terminal/ConPTY + VS Code Bridge",
      "purpose": "local command/process/workspace execution surface"
    },
    {
      "pr": 92,
      "title": "Studious Pancake Qualification Ops Runtime",
      "purpose": "flashloan campaign phases, commands, data, simulations, paper evidence"
    },
    {
      "pr": 93,
      "title": "Strategy Portfolio + Pre-mortem + Pivot Controller",
      "purpose": "alternate plans and localized strategy switching"
    },
    {
      "pr": 94,
      "title": "Skill/Tool Gating + Differential Evaluator",
      "purpose": "minimal relevant skills, negative-transfer protection"
    },
    {
      "pr": 95,
      "title": "Independent Process Auditor + Dense Progress/Credit",
      "purpose": "trajectory-level ground truth and progress signals"
    },
    {
      "pr": 96,
      "title": "24h+ Long-Horizon Windows/GUI/CLI Qualification",
      "purpose": "stress/restart/human coexistence and final metrics"
    }
  ],
  "dependency_note": "Do not skip still-unimplemented PR64–PR87 foundations. Re-number if GitHub numbers are no longer free."
}


---

## FILE: `ROUND_LEDGER_SCHEMA.json`

{
  "schema": "voice-agentos.round-ledger.v1",
  "round_id": "uuid",
  "goal_id": "id",
  "subgoal_id": "id",
  "manager_input": [
    "original goal ref",
    "last verified state",
    "failure evidence",
    "remaining acceptance"
  ],
  "execution_brief": {
    "objective": "one bounded step",
    "workspace": "exact workspace identity",
    "allowed_effects": [
      "effect"
    ],
    "resources": [
      "resource"
    ],
    "context_pack_digest": "sha256",
    "expected_postconditions": [
      "postcondition"
    ],
    "verifier": "verifier id"
  },
  "executor_receipt": "untrusted until audit",
  "auditor_receipt": "ACCEPT|REJECT|UNKNOWN",
  "accepted_progress": "only if audited",
  "failure_evidence": [],
  "folded_state_digest": "sha256"
}


---

## FILE: `SKILL_TOOL_GATING_RU.md`

# Skill / Tool Gating

Research in 2026 shows reusable agent skills can sometimes reduce success or increase cost.
Therefore the Railway must not dump every skill into every context.

## SkillCard

- skill id/version;
- goal/surface applicability;
- required preconditions;
- effect classes;
- historical success;
- known failure clusters;
- latency/token cost;
- conflicts;
- replay corpus;
- qualification status.

## Loader policy

1. Start with zero optional skills.
2. Retrieve only semantically relevant skills.
3. Prefer one minimal skill set.
4. If success degrades, compare against no-skill/reference run.
5. Quarantine a skill after attributed regressions.
6. Never let skill prose alter effect authority.

This also applies to provider tools and MCP/WebMCP tools.


---

## FILE: `STRATEGY_PORTFOLIO_PREMORTEM_PIVOT_RU.md`

# Strategy Portfolio / Pre-mortem / Pivot

Long-horizon tasks should not commit too early to one global plan.

## Trigger

Use a portfolio only when:
- task is high-value/long;
- first strategy has low calibrated success;
- multiple routes are materially different;
- failure would be expensive.

## Portfolio

2–4 StrategyCards:
- assumptions;
- subgoal graph;
- expected success prior from replay/history;
- latency;
- cost;
- human attention;
- risk;
- required capabilities;
- early discriminating experiment;
- pivot trigger.

## Pre-mortem

Choose likely failure classes from a fixed taxonomy:
- missing evidence;
- stale environment;
- wrong target;
- dependency drift;
- capability mismatch;
- tool negative transfer;
- resource conflict;
- context loss;
- verification weakness;
- external quota/network;
- user authority missing.

Do not ask the model for unlimited speculative prose. Store selected failure IDs and mitigations.

## Pivot

Pivot when:
- no meaningful progress for N audited rounds;
- evidence falsifies a core assumption;
- capability reliability falls below threshold;
- a better route's expected value exceeds current route by configured margin;
- resource/latency budget is exhausted.

Previous verified progress is retained.


---

## FILE: `WEB_RESEARCH_SYNTHESIS_RU.md`

# External research synthesis (October 2026)

## WeaveBench
Long-horizon real tasks require GUI + CLI + code within one trajectory. The original paper reports a best PassRate of 41.2% among evaluated frontier pairings and warns that outcome-only grading overestimates performance. Design implication: hybrid surfaces plus trajectory-aware independent verification.

Source:
https://www.microsoft.com/en-us/research/publication/weavebench-a-long-horizon-real-world-benchmark-for-computer-use-agents-with-hybrid-interfaces/

## Horizon Gap survey
A 2026 survey of 1,547 papers separates long-horizon tasks, long-context models and long-term memory systems, and emphasizes denser process-level signals as horizons grow. Design implication: persistent memory alone is not enough; planning/execution/evaluation need process signals.

Source:
https://arxiv.org/abs/2608.06663

## HIPIF
Hierarchical Planning and Information Folding organizes execution around explicit subgoals and folds completed histories to reduce context interference. Design implication: verified subgoal completion should produce folded state, not append endless chat history.

Source:
https://arxiv.org/abs/2606.10507

## Task-Decoupled Planning
TDP isolates contexts per subtask and reports lower token use and better robustness than entangled planning. Design implication: one mission may have many scoped fresh executor contexts.

Source:
https://arxiv.org/abs/2601.07577

## LongHorizon-Harness
A current open-source harness uses Manager → Executor → Auditor rounds, fresh execution contexts, verified checkpoint/recovery, GUI+CLI support and different backends per role. Its reported benchmark results show substantial gains over its baseline, but those are project-reported results and should be independently reproduced before being treated as guarantees.

Source:
https://github.com/AMAP-ML/LongHorizon-Harness

## MementoGUI and MemGym
Long-horizon GUI memory benefits from active selection/compression/retrieval, and agent memory should be evaluated separately from reasoning/tool ability. Design implication: memory is a controller, not a transcript dump.

Sources:
https://huggingface.co/papers/2605.18652
https://www.microsoft.com/en-us/research/publication/memgym-a-long-horizon-memory-environment-for-llm-agents/

## Skills can be harmful
Microsoft Research reports some skills can worsen success/cost. Design implication: dynamic minimal skill loading and differential replay, not "load every playbook".

Source:
https://www.microsoft.com/en-us/research/publication/agent-skills-can-be-harmful-an-empirical-study-of-skill-induced-failures-in-llm-agents/

## OpenHands / Agent Canvas
Current OpenHands separates control UI from execution backend and exposes browser/files/terminal/automation while the backend owns actual execution. Design implication: build AgentOS execution authority independently of VS Code and let IDEs be optional views.

Sources:
https://github.com/OpenHands/docs/blob/main/sdk/arch/agent.mdx
https://github.com/OpenHands/docs/blob/main/openhands/usage/agent-canvas/overview.mdx

## Magentic-UI
Human-agent systems benefit from co-planning, co-tasking, multi-tasking and action guards. Design implication: human takeover/release, approvals and visible lanes should remain first-class.

Source:
https://www.microsoft.com/en-us/research/publication/magentic-ui-report/

## WindowsWorld
Professional Windows tasks are strongly multi-app and need intermediate checkpoints. Design implication: Windows qualification must cover cross-application process flows, not isolated clicks.

Source:
https://github.com/HITsz-TMG/WindowsWorld

## Community signals (anecdotal)
Recent LocalLLaMA discussions repeatedly report context exhaustion/drift in long local tasks and favor bounded loops, memory/compaction, VM/sandbox separation and small-test/diff cycles. This is community experience, not benchmark evidence.

Sources:
https://www.reddit.com/r/LocalLLaMA/comments/1ro5plg/
https://www.reddit.com/r/LocalLLaMA/comments/1vvsgsp/
https://www.reddit.com/r/LocalLLaMA/comments/1u6mmuu/
