# Voice AgentOS — Long-Horizon Meta-Control / Qualification Ops PR88–PR96

This is a future completion wave after the PR64–PR87 foundations.

It does **not** mean PR64–PR87 may be skipped. Codex must always re-audit `main` and implement the first missing dependency.

The purpose of this pack is to increase long-horizon reliability by engineering the loop around Laya/System-2:

`goal → verified state → active mental frames → bounded subgoal → fresh scoped context → action → independent verification → checkpoint/recover → context fold → repeat`

Start in this order:
1. `MASTER_CONTEXT_RU.md`
2. `IMPLEMENTED_VS_MISSING_RU.md`
3. `MENTAL_FRAME_RAILWAY_V4_RU.md`
4. `LAYA_RAILWAY_V4_QUESTION_LIBRARY.json`
5. `LOCAL_DEV_WORKBENCH_RU.md`
6. `FLASHLOAN_QUALIFICATION_OPS_RU.md`
7. current PR spec.

Core invariant: one canonical durable Core, Goal runtime, resource/effect authority, Library, SurfaceGraph and capability system. Do not create a competing agent database or queue.
